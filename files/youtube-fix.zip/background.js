// Константы для улучшения читаемости
const SOURCE_DOMAIN = "yt3.ggpht.com";
const DESTINATION_DOMAIN = "yt4.ggpht.com";

// Функция для перенаправления запроса
const redirect = (requestDetails) => {
  
  
  // Формируем новый URL, заменяя исходный домен на целевой домен
  const redirectUrl = requestDetails.url.replace(SOURCE_DOMAIN, DESTINATION_DOMAIN);
  // Возвращаем объект с redirectUrl для перенаправления
  return { redirectUrl };
};

// Регистрируем перехватчик запросов
chrome.webRequest.onBeforeRequest.addListener(
  redirect, // Передаем функцию для перенаправления
  { urls: [`*://${SOURCE_DOMAIN}/*`], types: ["image"] }, // Перехватываем только изображения с исходного домена
  ["blocking"] // Используем режим блокировки для перенаправления
);
